counter = {"A": 0, "C": 0, "G": 0, "T": 0}
s = input()

for d in s:
    counter[d] += 1
    
print(counter["A"], counter["C"], counter["G"], counter["T"])