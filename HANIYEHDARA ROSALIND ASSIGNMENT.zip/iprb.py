def factorial(n):
    fact = 1
    
    for i in range(1, n + 1):
        fact *= i
    
    return fact

def comb(a, b):
    return factorial(a) / (factorial(b) * factorial(a - b))

k, m, n = (int(i) for i in input().split())

total = comb(k + m + n, 2) * 4

state_1 = comb(n, 2) * 4
state_2 = comb(m, 2)
state_3 = comb(n, 1) * comb(m, 1) * 2

states = state_1 + state_2 + state_3
result = (total - states) / total

print(result)
