numbers = list(map(int, input().split()))
counter = 0

for i in range(6):
    if i == 0 or i == 1 or i == 2:
        counter = counter + numbers[i] * 2
    elif i == 3:
        counter = counter + numbers[i] * 1.5
    elif i == 4:
        counter = counter + numbers[i]
    
print(counter)