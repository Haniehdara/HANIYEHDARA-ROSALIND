data = {"A": [], "C": [], "G": [], "T": []}
string = ""
flag = True

while True:
    try:
        st = input()
    except:
        break
    
    if st[0] == ">":
        if len(string) == 0:
            continue
        
        if flag:
            for key in data:
                data[key] = [0 for i in range(len(string))]

            flag = False
            
        for i in range(len(string)):
            data[string[i]][i] += 1
        
        string = ""
    else:
        string += st
        
if len(string) > 0:
    for i in range(len(string)):
        data[string[i]][i] += 1
        
ans = ""

for i in range(len(data['A'])):
    c = 0
    ch = ''
    
    for key in data:
        if data[key][i] > c:
            c = data[key][i]
            ch = key

    ans += ch
    
            
print(ans)

print("A:", end='')
for n in data['A']:
    print(" %d" % (n), end='')
print()
    
print("C:", end='')
for n in data['C']:
    print(" %d" % (n), end='')
print()
    
print("G:", end='')
for n in data['G']:
    print(" %d" % (n), end='')
print()
    
print("T:", end='')
for n in data['T']:
    print(" %d" % (n), end='')
print()
        
