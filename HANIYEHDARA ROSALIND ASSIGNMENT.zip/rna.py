d = {"A": "A", "C": "C", "G": "G", "T": "U"}
t = input()
u = ""

for i in range(len(t)):
    u = u + d[t[i]]
    
print(u)