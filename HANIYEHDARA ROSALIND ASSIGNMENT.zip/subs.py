s = input()
t = input()

out = ""
i = 0

while i + len(t) <= len(s):
    j = i + len(t)
    
    if s[i:j] == t:
        if out == "":
            out += str(i+1)
        else:
            out += " " + str(i+1)
            
    i += 1
            
print(out)