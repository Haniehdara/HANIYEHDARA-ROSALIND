d = {"A": "T", "C": "G", "G": "C", "T": "A"}
s = input()
ss = ""

for i in range(len(s)):
    ss = d[s[i]] + ss

print(ss)
