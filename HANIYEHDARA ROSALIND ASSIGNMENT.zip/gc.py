def cal_gc(s):
    g = s.count("G")
    c = s.count("C")
    
    if g + c == 0:
        return 0
    else:
        return (g + c) / len(s)

dataset = []
    
while True:
    try:
        s = input()
    except:
        break
    
    if s[0] == '>':
        if len(dataset) > 0:
            dataset[-1].append(cal_gc(dataset[-1][1]))
        
        dataset.append([s[1:], ""])
    else:
        dataset[-1][1] += s

dataset[-1].append(cal_gc(dataset[-1][1]))
gc_string = dataset[0][0]
gc_precision = dataset[0][2]

for i in range(1, len(dataset)):
    if dataset[i][2] > gc_precision:
        gc_string = dataset[i][0]
        gc_precision = dataset[i][2]
        
print(gc_string)
print(gc_precision)
